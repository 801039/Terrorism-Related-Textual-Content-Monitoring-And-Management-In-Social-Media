/*
Creating react project (terminal):
npx create-react-app serandib;

Installing tailwind css:
see for installation document in tailwind css site

firebase setup *************************************************************
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBsDoAi6gOhwf8CE781ve2tflnasRdckIg",
  authDomain: "sreandib-31544.firebaseapp.com",
  projectId: "sreandib-31544",
  storageBucket: "sreandib-31544.appspot.com",
  messagingSenderId: "254406003086",
  appId: "1:254406003086:web:924b2baed1d24e10f27cdf",
  measurementId: "G-RFVFNE8LPS"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
********************************************************************

//import react icons


01.02.40 min - sidebar search
01.07.24min - chat section
01.52.08 - backend
02.05.00 - mongodb
02.33.29
02.43.53

npx nodemon server

*/