import React from "react";

function SidebarLogo() {
  return (
    <div className="serandib__logo" class="block relative">
      <img
        src="https://github.com/801039/Logo-s-of-Serandib-apk/blob/main/serandib-low-resolution-logo-color-on-transparent-background.png?raw=true"
        alt=""
      />
    </div>
  );
}

export default SidebarLogo;
