// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBsDoAi6gOhwf8CE781ve2tflnasRdckIg",
    authDomain: "sreandib-31544.firebaseapp.com",
    projectId: "sreandib-31544",
    storageBucket: "sreandib-31544.appspot.com",
    messagingSenderId: "254406003086",
    appId: "1:254406003086:web:924b2baed1d24e10f27cdf",
    measurementId: "G-RFVFNE8LPS"
  };